package com.example.billsplit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class ConfirmPrice extends AppCompatActivity {

    private static final int MAXITEMS = 8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_price);

        for (int j = 0; j < MAXITEMS; j++) {
            String textViewID = "textView" + j;
            String editTextID = "editText" + j;
            int textID = getResources().getIdentifier(textViewID, "id", getPackageName());
            int editID = getResources().getIdentifier(editTextID, "id", getPackageName());
            TextView tv = findViewById(textID);
            EditText et = findViewById(editID);
            Log.d("logtag", "inside confirm price" + MainActivity.order + "");
            if (j < MainActivity.order.size()) {
                tv.setVisibility(View.VISIBLE);
                et.setVisibility(View.VISIBLE);
                String description = MainActivity.order.get(j);
                double predictedCost = MainActivity.map.get(description);
                tv.setText(description);
                et.setText("" + predictedCost);
                et.setOnFocusChangeListener((v, hasFocus) -> {
                    if (!hasFocus) {
                        updateTotal();
                        et.setText("" + stod(et.getText().toString()));
                        MainActivity.map.remove(description);
                        MainActivity.map.put(description, stod(et.getText().toString()));
                    }
                });
            } else {
                tv.setVisibility(View.INVISIBLE);
                et.setVisibility(View.INVISIBLE);
            }
        }
        EditText taxEditText = findViewById(R.id.editTextTax);
        taxEditText.setText("" + MainActivity.map.get("Tax"));
        taxEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                updateTotal();
                taxEditText.setText("" + stod(taxEditText.getText().toString()));
                MainActivity.map.remove("Tax");
                MainActivity.map.put("Tax", stod(taxEditText.getText().toString()));
            }
        });
        EditText tipEditText = findViewById(R.id.editTextTip);
        tipEditText.setText("" + 0);
        tipEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                updateTotal();
                tipEditText.setText("" + stod(tipEditText.getText().toString()));
                MainActivity.map.remove("Tip");
                MainActivity.map.put("Tip", stod(tipEditText.getText().toString()));
            }
        });

        updateTotal();
    }

    void updateTotal() {
        TextView tv = findViewById(R.id.textViewTotal);
        double sum = 0;
        for (int j = 0; j < MainActivity.order.size(); j++) {
            String editTextID = "editText" + j;
            int editID = getResources().getIdentifier(editTextID, "id", getPackageName());
            EditText et = findViewById(editID);
            sum += stod(et.getText().toString());
        }
        EditText taxEditText = findViewById(R.id.editTextTax);
        EditText tipEditText = findViewById(R.id.editTextTip);
        sum += stod(taxEditText.getText().toString());
        sum += stod(tipEditText.getText().toString());
        tv.setText("" + sum);
    }

    void resyncAllValues() {
        for (int j = 0; j < MainActivity.order.size(); j++) {
            String editTextID = "editText" + j;
            int editID = getResources().getIdentifier(editTextID, "id", getPackageName());
            EditText et = findViewById(editID);
            String description = MainActivity.order.get(j);
            MainActivity.map.remove(description);
            MainActivity.map.put(description, stod(et.getText().toString()));
        }
        EditText taxEditText = findViewById(R.id.editTextTax);
        MainActivity.map.remove("Tax");
        MainActivity.map.put("Tax", stod(taxEditText.getText().toString()));
        EditText tipEditText = findViewById(R.id.editTextTip);
        MainActivity.map.remove("Tip");
        MainActivity.map.put("Tip", stod(tipEditText.getText().toString()));
        updateTotal();
    }

    public static double stod(String s) {
        try {
            return Math.round(Double.parseDouble(s) * 100) / 100.0;
        } catch (Exception e) {
            return 0;
        }
    }

    public void launchEnterUsers(View view) {
        Log.d("logtag", "Button clicked!");
        resyncAllValues();
        Log.d("logtag", MainActivity.map.toString());
        Intent intent = new Intent(this, EnterUsers.class);
        startActivity(intent);
    }
}
