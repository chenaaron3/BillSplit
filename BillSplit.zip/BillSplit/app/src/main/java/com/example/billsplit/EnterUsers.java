package com.example.billsplit;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

public class EnterUsers extends AppCompatActivity {

    private static int MAXITEMS = 8;
    public static final int RequestPermissionCode = 1;
    EditText targetEditText;

    String name_base = "item_name_";
    String price_base = "text_price_";
    String phone_base = "phone_number_";
    String button_base = "button";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_users);

        EnableRuntimePermission();

        for (int j = 0; j < MAXITEMS; j++) {
            String nameStr = name_base + j;
            String priceStr = price_base + j;
            String phoneStr = phone_base + j;
            String buttonStr = button_base + j;
            int nameID = getResources().getIdentifier(nameStr, "id", getPackageName());
            int priceID = getResources().getIdentifier(priceStr, "id", getPackageName());
            int phoneID = getResources().getIdentifier(phoneStr, "id", getPackageName());
            int buttonID = getResources().getIdentifier(buttonStr, "id", getPackageName());
            TextView nameText = findViewById(nameID);
            TextView priceText = findViewById(priceID);
            EditText phoneText = findViewById(phoneID);
            Button button = findViewById(buttonID);
            if (j < MainActivity.order.size()) {
                nameText.setVisibility(View.VISIBLE);
                priceText.setVisibility(View.VISIBLE);
                phoneText.setVisibility(View.VISIBLE);
                button.setVisibility(View.VISIBLE);
                String description = MainActivity.order.get(j);
                double cost = MainActivity.map.get(description);
                Log.d("logtag", "Description: " + description + " Cost: " + cost);
                Log.d("logtag", "ID: " + nameStr + " " + priceStr + " " + phoneStr);
                nameText.setText(description);
                priceText.setText("$" + cost);
                phoneText.setOnFocusChangeListener((v, hasFocus) -> {
                    if (!hasFocus) {
                        String id = getResources().getResourceEntryName(phoneID);
                        int index = Integer.parseInt(id.substring(id.length() - 1));
                        MainActivity.userOrders.set(index, phoneText.getText().toString());
                    }
                });
            } else {
                nameText.setVisibility(View.INVISIBLE);
                priceText.setVisibility(View.INVISIBLE);
                phoneText.setVisibility(View.INVISIBLE);
                button.setVisibility(View.INVISIBLE);
            }
        }
    }

    // button press event for adding phone number
    public void addPhone(View view) {
        // targets the edit text
        String name = getResources().getResourceEntryName(view.getId());
        String phoneStr = phone_base + name.charAt(name.length() - 1);
        int phoneID = getResources().getIdentifier(phoneStr, "id", getPackageName());
        targetEditText = findViewById(phoneID);
        // opens contacts
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        startActivityForResult(intent, 7);
    }


    // enables permission for using contacts
    public void EnableRuntimePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(EnterUsers.this,
                Manifest.permission.READ_CONTACTS)) {
            Toast.makeText(EnterUsers.this, "CONTACTS permission allows us to Access CONTACTS app", Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(EnterUsers.this, new String[]{
                    Manifest.permission.READ_CONTACTS}, RequestPermissionCode);
        }
    }

    @Override
    public void onActivityResult(int RequestCode, int ResultCode, Intent ResultIntent) {
        super.onActivityResult(RequestCode, ResultCode, ResultIntent);
        if (ResultCode == Activity.RESULT_OK) {
            Uri uri;
            Cursor cursor1, cursor2;
            String TempNameHolder, TempNumberHolder, TempContactID, IDresult = "";
            int IDresultHolder;
            uri = ResultIntent.getData();
            cursor1 = getContentResolver().query(uri, null, null, null, null);
            if (cursor1.moveToFirst()) {
                TempNameHolder = cursor1.getString(cursor1.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                TempContactID = cursor1.getString(cursor1.getColumnIndex(ContactsContract.Contacts._ID));
                IDresult = cursor1.getString(cursor1.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));
                IDresultHolder = Integer.valueOf(IDresult);
                if (IDresultHolder == 1) {
                    cursor2 = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + TempContactID, null, null);
                    while (cursor2.moveToNext()) {
                        TempNumberHolder = cursor2.getString(cursor2.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        String originalContent = targetEditText.getText().toString();
                        String newContent = TempNumberHolder.replaceAll("[( )-+]", "").trim();
                        // first phone number
                        if(originalContent.length() == 0)
                        {
                            targetEditText.setText(newContent);
                        }
                        else
                        {
                            targetEditText.setText(originalContent + "," + newContent);
                        }
                        Log.d("logtag", TempNameHolder);
                        Log.d("logtag", TempNumberHolder);
                    }
                }
            }
        }
    }


    public void launchConfirmAmount(View view) {
        resyncAllValues();
        initializeUserCharges();
        Intent intent = new Intent(this, ConfirmAmount.class);
        startActivity(intent);
    }

    private void resyncAllValues() {
        for (int j = 0; j < MainActivity.order.size(); j++) {
            String phoneStr = phone_base + j;
            int phoneID = getResources().getIdentifier(phoneStr, "id", getPackageName());
            EditText phoneText = findViewById(phoneID);
            MainActivity.userOrders.set(j, phoneText.getText().toString());
        }
    }

    private void initializeUserCharges() {
        MainActivity.userCharges = new HashMap<String, Double>();
        Log.d("logtag", "Initializing User Charges");
        for (int j = 0; j < MainActivity.order.size(); j++) {
            String item = MainActivity.order.get(j);
            double itemCost = MainActivity.map.get(item);
            Log.d("logtag", "Item: " + item + " ItemCost: " + itemCost);
            for (String user : MainActivity.userOrders.get(j).trim().split(",")) {
                Log.d("logtag", "User: " + user);
                // if user already in charges
                if (MainActivity.userCharges.containsKey(user)) {
                    // adds to tab
                    double currentValue = MainActivity.userCharges.get(user);
                    double newValue = currentValue + itemCost;
                    MainActivity.userCharges.remove(user);
                    MainActivity.userCharges.put(user, newValue);
                } else {
                    // create a new tab
                    MainActivity.userCharges.put(user, itemCost);
                }
            }
        }
        if(MainActivity.userCharges.containsKey(""))
        {
            double val = MainActivity.userCharges.get("");
            MainActivity.userCharges.remove("");
            MainActivity.userCharges.put("No Charge", val);
        }
        Log.d("logtag", MainActivity.userCharges.toString());
    }
}
