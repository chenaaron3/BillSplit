package com.example.billsplit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.HashMap;

public class EnterUsers extends AppCompatActivity {

    private static int MAXITEMS = 8;

    String name_base = "item_name_";
    String price_base = "text_price_";
    String phone_base = "phone_number_";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_users);

        for (int j = 0; j < MAXITEMS; j++) {
            String nameStr = name_base + j;
            String priceStr = price_base + j;
            String phoneStr = phone_base + j;
            int nameID = getResources().getIdentifier(nameStr, "id", getPackageName());
            int priceID = getResources().getIdentifier(priceStr, "id", getPackageName());
            int phoneID = getResources().getIdentifier(phoneStr, "id", getPackageName());
            TextView nameText = findViewById(nameID);
            TextView priceText = findViewById(priceID);
            EditText phoneText = findViewById(phoneID);
            if (j < MainActivity.order.size()) {
                nameText.setVisibility(View.VISIBLE);
                priceText.setVisibility(View.VISIBLE);
                String description = MainActivity.order.get(j);
                double cost = MainActivity.map.get(description);
                Log.d("logtag", "Description: " + description + " Cost: " + cost);
                Log.d("logtag", "ID: " + nameStr + " " + priceStr + " " + phoneStr);
                nameText.setText(description);
                priceText.setText("$" + cost);
                phoneText.setOnFocusChangeListener((v, hasFocus) -> {
                    if (!hasFocus) {
                        String id = getResources().getResourceEntryName(phoneID);
                        int index = Integer.parseInt(id.substring(id.length() - 1));
                        MainActivity.userOrders.set(index, phoneText.getText().toString());
                    }
                });
            } else {
                nameText.setVisibility(View.INVISIBLE);
                priceText.setVisibility(View.INVISIBLE);
                phoneText.setVisibility(View.INVISIBLE);
            }
        }
    }

    public void launchConfirmAmount(View view) {
        resyncAllValues();
        initializeUserCharges();
        Intent intent = new Intent(this, ConfirmAmount.class);
        startActivity(intent);
    }

    private void resyncAllValues()
    {
        for (int j = 0; j < MainActivity.order.size(); j++) {
            String phoneStr = phone_base + j;
            int phoneID = getResources().getIdentifier(phoneStr, "id", getPackageName());
            EditText phoneText = findViewById(phoneID);
            MainActivity.userOrders.set(j, phoneText.getText().toString());
        }
    }

    private void initializeUserCharges() {
        MainActivity.userCharges = new HashMap<String, Double>();
        Log.d("logtag","Initializing User Charges");
        for (int j = 0; j < MainActivity.order.size(); j++) {
            String item = MainActivity.order.get(j);
            double itemCost = MainActivity.map.get(item);
            Log.d("logtag", "Item: " + item + " ItemCost: " + itemCost);
            for (String user : MainActivity.userOrders.get(j).trim().split(",")) {
                Log.d("logtag", "User: " + user);
                // if user already in charges
                if (MainActivity.userCharges.containsKey(user)) {
                    // adds to tab
                    double currentValue = MainActivity.userCharges.get(user);
                    double newValue = currentValue + itemCost;
                    MainActivity.userCharges.remove(user);
                    MainActivity.userCharges.put(user, newValue);
                } else {
                    // create a new tab
                    MainActivity.userCharges.put(user, itemCost);
                }
            }
        }
        Log.d("logtag", MainActivity.userCharges.toString());
    }
}
