package com.example.billsplit;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.text.DecimalFormat;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Credentials;
import okhttp3.Interceptor;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ConfirmAmount extends AppCompatActivity {

    private final int MAXITEMS = 8;

    // Twilio
    public static final String TWILIO_ACCOUNT_SID = "AC0a58fcfbf9719ce3f3c6d16bd6225477";
    public static final String TWILIO_AUTH_TOKEN = "41752b1ec3267080960e523a3da9093b";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_amount);

        Log.d("logtag", MainActivity.map.toString());
        Log.d("logtag", MainActivity.order.toString());
        Log.d("logtag", MainActivity.userOrders.toString());
        Log.d("logtag", MainActivity.userCharges.toString());

        String phone_base = "text_phone_";
        String price_base = "text_confirm_price_";

        String[] userSet = new String[MainActivity.userCharges.size()];
        MainActivity.userCharges.keySet().toArray(userSet);
        for (int j = 0; j < MAXITEMS; j++) {
            String priceStr = price_base + j;
            String phoneStr = phone_base + j;
            int priceID = getResources().getIdentifier(priceStr, "id", getPackageName());
            int phoneID = getResources().getIdentifier(phoneStr, "id", getPackageName());
            TextView phoneText = findViewById(phoneID);
            TextView priceText = findViewById(priceID);
            if (j < MainActivity.userCharges.size()) {
                phoneText.setVisibility(View.VISIBLE);
                priceText.setVisibility(View.VISIBLE);
                String user = userSet[j];
                phoneText.setText(user);
                priceText.setText(getCharge(user) + "");
            } else {
                phoneText.setVisibility(View.INVISIBLE);
                priceText.setVisibility(View.INVISIBLE);
            }
        }
    }

    private String getMessage(String user) {
        String res = "";
        double sum = 0;
        DecimalFormat df = new DecimalFormat("0.00");
        for (int j = 0; j < MainActivity.order.size(); j++) {
            if (MainActivity.userOrders.get(j).contains(user)) {
                String description = MainActivity.order.get(j);
                double price = MainActivity.map.get(description);
                res += description + ": $" + df.format(price) + "\n";
                sum += price;
            }
        }
        double percentage = sum / MainActivity.map.get("Subtotal");
        double percentTax = percentage * MainActivity.map.get("Tax");
        double percentTip = percentage * MainActivity.map.get("Tip");
        res += "Tax: $" + df.format(percentTax)+ "\n";
        res += "Tip: $" + df.format(percentTip) + "\n";
        String total = df.format(sum + percentTax + percentTip);
        res += "Total: $" + total + "\n";
        EditText pp = findViewById(R.id.paypal);
        res += "Pay at https://www.paypal.me/" + pp.getText() + "/" + total;
        return res;
    }

    private String getCharge(String user) {
        double sum = 0;
        for (int j = 0; j < MainActivity.order.size(); j++) {
            if (MainActivity.userOrders.get(j).contains(user)) {
                String description = MainActivity.order.get(j);
                double price = MainActivity.map.get(description);
                sum += price;
            }
        }
        double percentage = sum / MainActivity.map.get("Subtotal");
        double percentTax = percentage * MainActivity.map.get("Tax");
        double percentTip = percentage * MainActivity.map.get("Tip");
        double res = Math.round((sum + percentTax + percentTip) * 100) / 100;
        DecimalFormat df = new DecimalFormat("0.00");
        return "$" + df.format(res);
    }


    public void goHome(View view) {
        String[] userSet = new String[MainActivity.userCharges.size()];
        MainActivity.userCharges.keySet().toArray(userSet);
        for (int j = 0; j < userSet.length; j++) {
            String user = userSet[j];
            Handler handler = new Handler();
            handler.postDelayed(() -> {
                sendSMSMagic(user, getMessage(user));
                Toast toast = Toast.makeText(this, "Sent request to " + user, Toast.LENGTH_SHORT);
                toast.show();
            }, 1500 * j);
        }
//        Intent intent = new Intent(this, MainActivity.class);
//        startActivity(intent);
    }

    // class for HTTP basic authentication
    class BasicAuthInterceptor implements Interceptor {
        private String credentials;

        public BasicAuthInterceptor(String user, String password) {
            this.credentials = Credentials.basic(user, password);
        }

        @Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request();
            Request authenticatedRequest = request.newBuilder()
                    .header("Authorization", credentials).build();
            return chain.proceed(authenticatedRequest);
        }
    }

    // TWILIO
    public void sendSMSTwilio(String phone, String message) {
        // for pop up authorization
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(new BasicAuthInterceptor(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN))
                .build();
        System.out.println("Building Request...");

        RequestBody formBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("Body", message)
                .addFormDataPart("To", "+" + phone)
                .addFormDataPart("From", "+18312784801")
                .build();

        String url = "https://api.twilio.com/2010-04-01/Accounts/" + TWILIO_ACCOUNT_SID + "/Messages";

        Request request = new Request.Builder()
                .url(url)
                .post(formBody)
                .build();

        System.out.println("Sending Request...");

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println("Failed");
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                System.out.println("Responded: " + response.toString());
                if (response.isSuccessful()) {
                    System.out.println("Success!!");
                    final String myResponse = response.body().string();
                    System.out.println(myResponse);
                    response.body().close();
                }
            }
        });
    }

    // TEXTMAGIC
    public void sendSMSMagic(String phone, String message) {
//        phone = "17073427165";//"14086149698";
        String user = "aaronchen1";
        String password = "7IpruzMLeissVKmKhhlwVafoPfDXhf";

        //
        // aaronchen3 : Do7g2dROp2s55MCE3BQJaS5qWNvsq7
        // 	aaronchen4 : 4TNdx2um9G7PjUKVEQH08KN1q3j9XG

        OkHttpClient client = new OkHttpClient();
        System.out.println("Building Request...");

        RequestBody formBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("text", message)
                .addFormDataPart("phones", phone)
                .build();

        String url = "https://rest.textmagic.com/api/v2/messages";

        Request request = new Request.Builder()
                .url(url)
                .addHeader("X-TM-Username", user)
                .addHeader("X-TM-Key", password)
                .post(formBody)
                .build();

        System.out.println("Sending Request...");

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println("Failed");
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                System.out.println("Responded: " + response.toString());
                if (response.isSuccessful()) {
                    System.out.println("Success!!");
                    final String myResponse = response.body().string();
                    System.out.println(myResponse);
                    response.body().close();
                }
            }
        });
    }
}
