package com.example.billsplit;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    // CODES
    private static final int PERMISSION_REQUEST_CODE = 200;
    private static final int REQUEST_IMAGE_CAPTURE = 11;
    private static final int REQUEST_IMAGE = 21;

    // API KEYS
    private static final String TAGGUN_API_KEY = "37036f405a7b11e98bfadfb7eb1aa8b5";

    // COMPONENTS
    public static HashMap<String, Double> map; // key is item description, value is item price
    public static LinkedList<String> order; // the order that items appear on the receipt
    public static LinkedList<String> userOrders; // outer list correspond to item
            // inner list correspond to users subscribed, comma separated
    public static HashMap<String, Double> userCharges; // key is user, value is price owed no tax/tip

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // checks permission for camera
        if (!checkPermission()) {
            requestPermission();
        }
        findViewById(R.id.progressBarScan).setVisibility(View.INVISIBLE);
        findViewById(R.id.button_scan).setVisibility(View.VISIBLE);
    }

    @Override
    protected void onActivityResult(int reqCode, int resultCode, Intent data) {
        super.onActivityResult(reqCode, resultCode, data);

        // result from capturing an image
        if (reqCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            Log.d("logtag", "Photo Taken!");
            File file = bitmapToFile(imageBitmap);
            postApi(file);
            findViewById(R.id.progressBarScan).setVisibility(View.VISIBLE);
            findViewById(R.id.button_scan).setVisibility(View.INVISIBLE);
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    findViewById(R.id.progressBarScan).setVisibility(View.INVISIBLE);
                    findViewById(R.id.button_scan).setVisibility(View.VISIBLE);
                }
            }, 5000);   //5 seconds
        }

        if (resultCode == RESULT_OK && reqCode == REQUEST_IMAGE) {
            try {
                Log.d("logtag","Processing Image...");
                final Uri imageUri = data.getData();
                final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                File file = bitmapToFile(selectedImage);
                // requests + parses + assigns static values
                postApi(file);
                findViewById(R.id.progressBarScan).setVisibility(View.VISIBLE);
                findViewById(R.id.button_scan).setVisibility(View.INVISIBLE);
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    public void run() {
                        findViewById(R.id.progressBarScan).setVisibility(View.INVISIBLE);
                        findViewById(R.id.button_scan).setVisibility(View.VISIBLE);
                    }
                }, 5000);   //5 seconds
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    // take picture
    public void dispatchTakePictureIntent(View view) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            Log.d("logtag", "Taking Photo...");
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    // emulator testing
    public void pickPicture(View view)
    {
        // prompts user to pick a photo
        Log.d("logtag","Selecting Image...");
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, REQUEST_IMAGE);
    }

    // convert bitmap to File
    File bitmapToFile(Bitmap bm) {
        Log.d("logtag", "Converting Bitmap to File...");
        //create a file to write bitmap data
        File f = new File(this.getCacheDir(), "receipt.png");
        try {
            f.createNewFile();
        } catch (java.io.IOException e) {
        }

        //Convert bitmap to byte array
        Bitmap bitmap = bm;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0 /*ignored for PNG*/, bos);
        byte[] bitmapdata = bos.toByteArray();

        //write the bytes in file
        try {
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(bitmapdata);
            fos.flush();
            fos.close();
        } catch (java.io.FileNotFoundException e) {
        } catch (java.io.IOException e) {
        }
        Log.d("logtag", "Finished Converting Bitmap to File!");
        return f;
    }

    // TAGGUN
    void postApi(File content) {
        String url = "https://api.taggun.io/api/receipt/v1/verbose/file";
        Log.d("logtag", "Creating Client...");
        OkHttpClient client = new OkHttpClient();

        Log.d("logtag", "Building Request...");

        RequestBody formBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", "receipt.png", RequestBody.create(MediaType.parse("text/png"), content))
                .build();

        Request request = new Request.Builder()
                .url(url)
                .addHeader("apikey", TAGGUN_API_KEY)
                .post(formBody)
                .build();

        Log.d("logtag","Sending Request...");

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d("logtag","Failed");
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    Log.d("logtag","Success!!");
                    String myResponse = response.body().string();
                    Log.d("logtag",myResponse);
                    try
                    {
                        parseItems(myResponse);
                        goNext();
                        response.body().close();
                    }
                    catch(org.json.simple.parser.ParseException e)
                    {
                        Log.d("logtag", "failed response");
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    public void goNext()
    {
        Log.d("logtag", "Going next");
        Intent intent = new Intent(this, ConfirmPrice.class);
        startActivity(intent);
    }


    public static void parseItems(String json) throws FileNotFoundException, IOException, ParseException
    {
        // parsing file "JSONExample.json"
        Object obj = new JSONParser().parse(json);
        // typecasting obj to JSONObject
        JSONObject jo = (JSONObject) obj;
        // gets summed values
        try
        {
            double total = 0;
            double tax = 0;
            try
            {
                total = Double.parseDouble(((JSONObject) jo.get("totalAmount")).get("data").toString());
            }
            catch(java.lang.NullPointerException e)
            {
            }
            try
            {
                tax = Double.parseDouble(((JSONObject) jo.get("taxAmount")).get("data").toString());
            }
            catch(java.lang.NullPointerException e)
            {
            }
            double subtotal = total - tax;
            // creates an iterator to iterate through individual items
            Iterator<JSONObject> i = ((JSONArray) jo.get("amounts")).iterator();
            // keeps track of the sum of items
            double sum = 0;
            // if process went well or not
            boolean oopsie = false;
            map = new HashMap<String, Double>();
            order = new LinkedList<>();

            while (i.hasNext())
            {
                JSONObject amount = i.next();
                String text = amount.get("text").toString();
                double data = Double.parseDouble(amount.get("data").toString());
                text = text.replace("" + data, "");
                Log.d("logtag","Data: " + data + " Text: " + text);
                sum += data;
                // accumulates the string rep
                map.put(text, data);
                order.add(text);
                // if items add up exactly to subtotal
                if (subtotal == sum)
                {
                    break;
                }
                // if sum is somehow greater than the subtotal
                else if (sum > subtotal)
                {
                    oopsie = true;
                    break;
                }
            }
            // adds values to map
            map.put("Subtotal", subtotal);
            map.put("Tax", tax);
            map.put("Tip", 0.00);
            map.put("Total", total);

            // creates userOrders
            userOrders = new LinkedList<String>();
            for(int j = 0; j < order.size(); j++)
            {
                userOrders.add("");
            }

            Log.d("logtag", map.toString());
            Log.d("logtag", order.toString());
        }
        catch(java.lang.NullPointerException e)
        {
            Log.d("logtag", "failed parsing");
            e.printStackTrace();
        }
    }

    private boolean checkPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            return false;
        }
        return true;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                PERMISSION_REQUEST_CODE);
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                PERMISSION_REQUEST_CODE);
    }
}
